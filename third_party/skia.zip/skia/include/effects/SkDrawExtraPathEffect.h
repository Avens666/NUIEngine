/*
 * Copyright 2008 The Android Open Source Project
 *
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

#ifndef SK_DRAW_EXTRA_PATH_EFFECT_H
#define SK_DRAW_EXTRA_PATH_EFFECT_H

class SkAnimator;

void InitializeSkExtraPathEffects(SkAnimator* animator);

#endif
